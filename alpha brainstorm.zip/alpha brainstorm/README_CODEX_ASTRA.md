# ES Full-Auto Alpha Research — Phase 4 Master (Audited)

## Principle
Only hard-data results are treated as backtests. Historical S&P 500 correction statistics before the available ES intraday dataset are context only.

## Phase 4 audit
This phase reimplemented the signal engine independently from raw 1-minute ES data. Some Phase 3 candidates weakened or failed under the stricter reimplementation. They are retained and explicitly downgraded rather than hidden.

## Real-time dashboard metrics
- current price
- highest historical RTH high
- drawdown_from_ATH (%)
- drawdown bucket: 0–5 / 5–10 / 10–15 / 15–20 / 20+
- prior close vs MA200
- ATR20
- session VWAP and VWAP z
- prior-day POC / VAH / VAL / high / low
- overnight high / low
- OR15 / OR30
- 5m delta and cumulative-delta divergence
- active strategy IDs
- recommended research sizing multiplier (display only until production gates pass)

## Critical rule
Never convert the drawdown sizing schedule into live leverage merely because historical net P&L increases. Phase 4 shows that moderate/aggressive scaling increased total P&L but also increased drawdown and slightly reduced PF.

See `codex_astra_strategy_spec.json` for machine-readable definitions.
