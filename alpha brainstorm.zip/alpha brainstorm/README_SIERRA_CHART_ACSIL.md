# ES FULL-AUTO SYSTEMS — SIERRA CHART / ACSIL IMPLEMENTATION README

**Version:** Phase 4 Master Audit  
**Target platform:** Sierra Chart, ACSIL (C++)  
**Instrument:** ES futures  
**Primary execution style:** fully mechanical / full-auto  
**Research contract:** hard-data only, no discretionary inputs, no hidden hindsight

---

## 1. Purpose

This README is the canonical implementation guide for porting the audited ES research strategies into Sierra Chart ACSIL.

The implementation must reproduce the research engine **feature by feature and timestamp by timestamp** before any live trading is enabled.

The primary design principle is:

> `REGIME -> LOCATION -> CONDITION -> CONFIRMATION -> ENTRY -> EXIT -> RISK`

No strategy may use subjective concepts such as "looks exhausted", "strong absorption", "good profile", or "nice reversal". Every such concept must be represented by explicit numerical rules.

---

## 2. Non-negotiable parity rules

These rules define the backtest/live contract.

1. **RTH session:** 09:30:00–16:00:00 New York exchange time.
2. **Signal timeframe:** completed 5-minute RTH bars.
3. **No look-ahead:** a signal can only use data available at the 5-minute bar close.
4. **Entry:** next available 1-minute bar open after the signal bar closes.
5. **Maximum first signal:** one first entry per strategy per RTH session unless a future research version explicitly changes this.
6. **Delta:** `AskVolume - BidVolume`.
7. **30-minute cumulative-delta divergence:** current 5m close is below the close 30 minutes earlier while session cumulative delta is above cumulative delta 30 minutes earlier.
8. **ATR20:** 20-session average true range on completed RTH daily sessions.
9. **MA200:** 200 completed RTH daily closes.
10. **ATH drawdown:** current/entry price divided by the highest **prior RTH high** in available history minus 1.
11. **VWAP:** session cumulative volume-weighted typical price.
12. **VWAP sigma:** cumulative volume-weighted standard deviation of session typical price.
13. **Market Profile:** prior-day custom TPO reconstruction using:
    - 30-minute TPO periods,
    - 0.25 ES point price bins,
    - 70% value area,
    - POC = price bin with maximum TPO count,
    - VAL/VAH from the selected 70% set.
14. **Liquidity sweep/reclaim:** bar low trades below the reference level and the completed bar closes back above it.
15. **Execution ambiguity:** if both TP and SL are touched in the same 1-minute bar, count the **SL first**.
16. **Time stop:** 120 minutes from entry unless overridden in a future version.
17. **Backtest friction:** 0.5 ES point round trip in research comparison.
18. **No pre-2018 order-flow reconstruction:** never synthesize BidVolume/AskVolume for periods where they do not exist.

---

## 3. Recommended ACSIL architecture

Use one DLL project but split the logic conceptually into modules.

### Suggested source files

```text
ESAlpha/
  ESAlphaMain.cpp
  ESAlphaFeatures.h
  ESAlphaFeatures.cpp
  ESAlphaProfiles.h
  ESAlphaProfiles.cpp
  ESAlphaStrategies.h
  ESAlphaStrategies.cpp
  ESAlphaExecution.h
  ESAlphaExecution.cpp
  ESAlphaRisk.h
  ESAlphaRisk.cpp
  ESAlphaDiagnostics.h
  ESAlphaDiagnostics.cpp
  ESAlphaTypes.h
```

If simplicity is preferred, all code can initially live in one `.cpp`, but the public interfaces below should still be preserved.

### Core structs

```cpp
struct DailyState
{
    float PriorClose;
    float PriorHigh;
    float PriorLow;
    float ATR20;
    float MA200;
    float PriorATH;
    float DrawdownFromATH;
    float PriorPOC;
    float PriorVAH;
    float PriorVAL;
    float OvernightHigh;
    float OvernightLow;
    bool Bull200;
    bool TwoPriorDownDays;
};

struct IntradayState
{
    float VWAP;
    float VWAPSigma;
    float VWAPZ;
    float Delta5;
    float CumDelta;
    float CumDelta30Ago;
    float Close30Ago;
    float Return30m;
    float Return60m;
    int LowerCloseStreak;
    float OR15Low;
    float OR30Low;
    bool DeltaDiv30;
    bool DeltaFlipPositive;
};

struct StrategySignal
{
    bool LongSignal;
    int StrategyID;
    float TP_ATR;
    float SL_ATR;
    int Quantity;
};
```

---

## 4. Sierra Chart study configuration

Recommended main study:

```cpp
SCSFExport scsf_ESAlphaEngine(SCStudyInterfaceRef sc)
```

In `sc.SetDefaults`:

```cpp
sc.GraphName = "ES Alpha Full-Auto Engine";
sc.StudyDescription = "Mechanical ES long-bias multi-factor strategy engine";
sc.AutoLoop = 0;
sc.UpdateAlways = 1;
sc.MaintainVolumeAtPriceData = 1;
sc.GraphRegion = 0;
sc.AllowMultipleEntriesInSameDirection = 0;
sc.AllowOppositeEntryWithOpposingPositionOrOrders = 0;
sc.CancelAllOrdersOnEntriesAndReversals = 0;
sc.CancelAllWorkingOrdersOnExit = 1;
sc.SupportReversals = 0;
sc.AllowEntryWithWorkingOrders = 0;
```

Manual looping is recommended because the engine must coordinate multiple time/state calculations and should process from `sc.UpdateStartIndex`, never from index zero on every chart update.

---

## 5. New-bar gating

Never fire a signal repeatedly on each Chart Update Interval.

The trading decision must run only once after a new completed 5-minute bar becomes available.

Recommended design:

```cpp
int& LastProcessedBarIndex = sc.GetPersistentInt(1);

const int LastClosedIndex = sc.ArraySize - 2;

if (LastClosedIndex <= LastProcessedBarIndex)
    return;

LastProcessedBarIndex = LastClosedIndex;
```

Also protect trading from recalculation / historical download:

```cpp
if (sc.IsFullRecalculation || sc.DownloadingHistoricalData)
    return;
```

For historical calculations you may calculate features during a full recalculation, but **do not submit orders**.

---

## 6. Required chart setup

### Execution chart
- ES continuous or active contract chart.
- 1-minute Intraday Chart.
- Bid/Ask volume storage enabled.
- Correct ES Tick Size = 0.25.
- Correct Session Times including evening data if overnight levels are required.

### Signal aggregation
Two acceptable approaches:

**Preferred:** the ACSIL study runs on a 1-minute chart and internally aggregates completed 5-minute RTH windows.

**Alternative:** use a dedicated 5-minute signal chart and a 1-minute execution chart, with direct cross-chart referencing.

The first approach reduces chart synchronization risk.

---

## 7. Accessing Bid/Ask and Volume-at-Price

The backtest uses per-bar BidVolume and AskVolume.

At ordinary bar level:

```cpp
float BidVolume = sc.BaseData[SC_BIDVOL][Index];
float AskVolume = sc.BaseData[SC_ASKVOL][Index];
float Delta = AskVolume - BidVolume;
```

When price-level data are needed:

```cpp
sc.MaintainVolumeAtPriceData = 1;
```

Use `sc.VolumeAtPriceForBars` and `s_VolumeAtPriceV2`.

Do not calculate a historical delta from total volume if Bid/Ask data are unavailable.

---

## 8. Session state machine

At the first RTH bar of each session:

1. finalize prior RTH daily OHLC,
2. update ATR20,
3. update MA200,
4. update historical ATH,
5. calculate previous-day TPO POC/VAH/VAL,
6. calculate overnight high/low,
7. clear:
   - cumulative RTH volume,
   - cumulative PV,
   - cumulative squared-price-volume,
   - cumulative delta,
   - OR15 / OR30,
   - daily per-strategy traded flags.

Pseudo:

```cpp
if (IsFirstRTHBar(Index))
{
    FinalizePreviousSession();
    UpdateATR20();
    UpdateMA200();
    UpdateATH();
    BuildPriorDayTPOProfile();
    ComputeOvernightLevels();

    ResetIntradayAccumulators();
    ResetStrategyDailyFlags();
}
```

---

## 9. Daily ATR20

True Range for completed RTH session:

```text
TR = max(
    DailyHigh - DailyLow,
    abs(DailyHigh - PreviousClose),
    abs(DailyLow - PreviousClose)
)
```

Then:

```text
ATR20 = SMA(last 20 completed RTH true ranges)
```

Use only completed sessions. Never use today's unfinished high/low in ATR20.

---

## 10. MA200 / bull regime

```text
MA200 = SMA(last 200 completed RTH closes)
Bull200 = PreviousRTHClose > PreviousMA200
```

The prior close and prior MA are used because the signal must not contain future end-of-day information.

---

## 11. Absolute-high drawdown state

Maintain:

```cpp
PersistentPriorATH = max(PersistentPriorATH, CompletedDailyHigh);
```

Before today's session starts, this represents the highest completed RTH high known at that time.

For each signal:

```text
DrawdownFromATH = SignalPrice / PriorATH - 1
```

Buckets:

```text
0 to -5%      -> DD_0_5
-5 to -10%    -> DD_5_10
-10 to -15%   -> DD_10_15
-15 to -20%   -> DD_15_20
<= -20%       -> DD_20_PLUS
```

Dashboard should always display:
- Prior ATH,
- current price,
- drawdown %,
- drawdown bucket,
- Bull/Bear MA200 regime.

Do **not** automatically increase live position size based solely on this bucket until the risk layer is separately approved.

---

## 12. Session VWAP and sigma

For each completed 5-minute RTH bar:

```text
TypicalPrice = (High + Low + Close) / 3
CumVolume += Volume
CumPV += TypicalPrice * Volume
CumP2V += TypicalPrice^2 * Volume

VWAP = CumPV / CumVolume
Variance = max(CumP2V / CumVolume - VWAP^2, 0)
VWAPSigma = sqrt(Variance)
VWAPZ = (Close - VWAP) / VWAPSigma
```

Never substitute Sierra's native VWAP formula unless a parity test proves the output is identical at every research timestamp.

---

## 13. Delta / cumulative delta

For each source bar:

```text
Delta = AskVolume - BidVolume
```

For the 5-minute signal bar:

```text
Delta5 = sum(1-minute delta in current 5-minute window)
CumDelta = running sum of Delta5 from 09:30
```

### Bullish 30-minute delta divergence

```text
CloseNow < Close30MinutesAgo
AND
CumDeltaNow > CumDelta30MinutesAgo
```

This exact definition is intentionally simple and deterministic.

---

## 14. Delta flip

```text
CurrentDelta5 > 0
AND
PreviousDelta5 <= 0
```

---

## 15. 15/30-minute opening range

```text
OR15Low = minimum low from 09:30 through 09:44:59
OR30Low = minimum low from 09:30 through 09:59:59
```

OR15 sweep/reclaim signals cannot occur before 09:45.  
OR30 sweep/reclaim signals cannot occur before 10:00.

---

## 16. Overnight levels

Research definition:

```text
Overnight session = previous calendar day 18:00:00 through current day 09:29:59
```

Calculate:
- OvernightHigh,
- OvernightLow.

Ensure the chart contains evening-session data.

---

## 17. Custom TPO Market Profile

For research parity, **do not depend on native TPO internals**.

Reconstruct previous RTH TPO mechanically:

1. Split prior RTH into 30-minute periods.
2. For each 30-minute High/Low, enumerate every 0.25-point price bin touched.
3. Increment TPO count once for that period at each touched price.
4. POC = price with highest count.
5. Sort price bins by count descending.
6. Add bins until at least 70% of total TPO count is included.
7. VAL = minimum price in the selected set.
8. VAH = maximum price in the selected set.

Tie-breaking must be deterministic. Recommended:
- if multiple POCs share maximum count, choose the one closest to the profile midpoint;
- if still tied, choose the lower price.

Document the chosen tie rule and keep it identical in Python and ACSIL.

---

## 18. Liquidity sweep/reclaim

Generic helper:

```cpp
bool SweepReclaim(float BarLow, float BarClose, float Level)
{
    return BarLow < Level && BarClose > Level;
}
```

Reference levels can be:
- prior-day low,
- overnight low,
- OR15 low,
- OR30 low.

---

## 19. Order submission

Prefer Sierra Chart managed automated trading for same-symbol execution.

Build a fresh `s_SCNewOrder`.

Conceptual example:

```cpp
s_SCNewOrder NewOrder;
NewOrder.OrderQuantity = Quantity;
NewOrder.OrderType = SCT_ORDERTYPE_MARKET;

// Attached target and stop are calculated from ATR and converted to price offsets.
NewOrder.Target1Offset = TargetPoints;
NewOrder.Stop1Offset = StopPoints;

int Result = sc.BuyEntry(NewOrder);
```

Alternatively use programmatic Attached Orders.

Before live enablement:
- run SIM,
- verify all order IDs,
- verify bracket creation,
- verify quantity,
- verify flatten logic.

---

## 20. Daily trade guard

Every strategy needs its own persistent "already traded today" state.

```cpp
int& TradedTodayStrategy01 = sc.GetPersistentInt(101);
```

Reset at new RTH session.

Before signal:

```cpp
if (TradedTodayStrategy01)
    return;
```

After accepted entry:

```cpp
TradedTodayStrategy01 = 1;
```

---

## 21. Global risk gates

Before every order require:

```text
TradingEnabled == true
IsRTH == true
BarClosed == true
NoExistingPosition == true
NoWorkingEntryOrder == true
StrategyNotAlreadyTradedToday == true
DailyLossLimitNotExceeded == true
MaxContractsNotExceeded == true
ConnectionHealthy == true
```

Recommended Inputs:
- Master Enable,
- Enable Long Entries,
- SIM Only Safety Lock,
- Max Position Quantity,
- Daily Loss Limit,
- Max Number of Entries per Day,
- Start Time,
- Last Entry Time,
- Flatten Time,
- Friction/Slippage diagnostic input,
- individual Enable/Disable for every strategy.

---

## 22. Diagnostic outputs / dashboard

Expose subgraphs or text fields for:

```text
Price
Prior ATH
Drawdown from ATH %
Drawdown bucket
Prior close
MA200
Bull200
ATR20
VWAP
VWAP sigma
VWAP z
Prior PDL
Prior POC
Prior VAH
Prior VAL
Overnight Low
OR15 Low
OR30 Low
Delta5
CumDelta
DeltaDiv30
Lower Close Streak
Active Strategy ID
Position Size Research Multiplier
Live/SIM status
```

The dashboard is informational. Sizing multiplier must be display-only until approved.

---

## 23. Strategy implementation registry

Every strategy should be coded as an isolated pure Boolean function:

```cpp
bool Strategy_BullGap02PDLReclaim(
    const DailyState& D,
    const IntradayState& I,
    const SignalBar& B)
{
    return
        D.Bull200
        && I.RTHGap <= -0.002f
        && B.Low < D.PriorLow
        && B.Close > D.PriorLow
        && I.Delta5 > 0;
}
```

A strategy function must not:
- submit orders,
- alter position quantity,
- read future bars,
- calculate unrelated indicators.

It only returns `true/false`.

The execution layer handles the trade.

---


## 25. Strategy: `ATH_DD15_PDL_Div`

**Family:** ath_drawdown  
**Audit status:** RESEARCH_ONLY  
**Research rule:** drawdown from prior absolute RTH ATH <= -15% + PDL sweep/reclaim + delta divergence  
**TP:** 0.75 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 24 trades  
**Net expectancy:** -0.833 ES points/trade  
**PF:** 0.894  
**Max DD:** 79.00 ES points  
**Discovery / Validation / OOS:** -5.417 / 7.562 / 0.750  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.
- Use the prior historical RTH ATH; do not let today's future high enter the calculation.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 26. Strategy: `ATH_DD8_PDL_Div`

**Family:** ath_drawdown  
**Audit status:** RESEARCH_ONLY  
**Research rule:** drawdown from prior absolute RTH ATH <= -8% + PDL sweep/reclaim + delta divergence  
**TP:** 0.75 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 52 trades  
**Net expectancy:** -0.865 ES points/trade  
**PF:** 0.891  
**Max DD:** 112.50 ES points  
**Discovery / Validation / OOS:** -2.129 / 2.853 / -11.625  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.
- Use the prior historical RTH ATH; do not let today's future high enter the calculation.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 27. Strategy: `ATH_DD10_PDL_Div`

**Family:** ath_drawdown  
**Audit status:** RESEARCH_ONLY  
**Research rule:** drawdown from prior absolute RTH ATH <= -10% + PDL sweep/reclaim + delta divergence  
**TP:** 0.75 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 41 trades  
**Net expectancy:** -1.335 ES points/trade  
**PF:** 0.848  
**Max DD:** 135.00 ES points  
**Discovery / Validation / OOS:** -3.839 / 4.333 / 0.750  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.
- Use the prior historical RTH ATH; do not let today's future high enter the calculation.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 28. Strategy: `ATH_DD5_PDL_Div`

**Family:** ath_drawdown  
**Audit status:** RESEARCH_ONLY  
**Research rule:** drawdown from prior absolute RTH ATH <= -5% + PDL sweep/reclaim + delta divergence  
**TP:** 0.75 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 80 trades  
**Net expectancy:** -2.362 ES points/trade  
**PF:** 0.741  
**Max DD:** 293.35 ES points  
**Discovery / Validation / OOS:** -5.377 / 2.906 / -0.074  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.
- Use the prior historical RTH ATH; do not let today's future high enter the calculation.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 29. Strategy: `ATH_DD20_PDL_Div`

**Family:** ath_drawdown  
**Audit status:** RESEARCH_ONLY  
**Research rule:** drawdown from prior absolute RTH ATH <= -20% + PDL sweep/reclaim + delta divergence  
**TP:** 0.75 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 8 trades  
**Net expectancy:** -14.875 ES points/trade  
**PF:** 0.010  
**Max DD:** 57.00 ES points  
**Discovery / Validation / OOS:** -18.750 / -3.250 /   

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.
- Use the prior historical RTH ATH; do not let today's future high enter the calculation.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 30. Strategy: `DD2_AboveMA200_PDL_Sweep`

**Family:** correction  
**Audit status:** CANDIDATE  
**Research rule:** bull200 + prior close <= -2% from 252d high + PDL sweep/reclaim  
**TP:** 1.00 × ATR20  
**SL:** 1.50 × ATR20  
**Phase-4 sample:** 242 trades  
**Net expectancy:** 2.162 ES points/trade  
**PF:** 1.326  
**Max DD:** 205.75 ES points  
**Discovery / Validation / OOS:** -0.436 / 1.135 / 9.552  

### Sierra implementation

- Maintain trailing 252-session high using only completed data.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 1.00 * ATR20
     stop   = entry - 1.50 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 31. Strategy: `2Down_Bull_VWAPz0.75_Flip`

**Family:** multiday  
**Audit status:** CANDIDATE  
**Research rule:** 2 prior down days + bull200 + VWAP z<=-0.75 + delta flip positive  
**TP:** 0.75 × ATR20  
**SL:** 1.50 × ATR20  
**Phase-4 sample:** 224 trades  
**Net expectancy:** 1.782 ES points/trade  
**PF:** 1.260  
**Max DD:** 162.50 ES points  
**Discovery / Validation / OOS:** -1.188 / 1.642 / 6.237  

### Sierra implementation

- Use the custom cumulative session VWAP/sigma implementation; do not silently switch formulas.
- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.50 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 32. Strategy: `2Down_Bull_VWAPz1.0_Flip`

**Family:** multiday  
**Audit status:** CANDIDATE  
**Research rule:** 2 prior down days + bull200 + VWAP z<=-1.0 + delta flip positive  
**TP:** 0.75 × ATR20  
**SL:** 1.50 × ATR20  
**Phase-4 sample:** 207 trades  
**Net expectancy:** 1.199 ES points/trade  
**PF:** 1.166  
**Max DD:** 160.75 ES points  
**Discovery / Validation / OOS:** -1.034 / 1.096 / 4.460  

### Sierra implementation

- Use the custom cumulative session VWAP/sigma implementation; do not silently switch formulas.
- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.50 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 33. Strategy: `Bull_Gap0.2_PDL_Reclaim`

**Family:** gap  
**Audit status:** CANDIDATE  
**Research rule:** bull200 + RTH gap<=-0.2% + PDL sweep/reclaim + positive delta  
**TP:** 0.25 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 204 trades  
**Net expectancy:** 0.969 ES points/trade  
**PF:** 1.185  
**Max DD:** 154.38 ES points  
**Discovery / Validation / OOS:** 0.167 / 0.973 / 2.620  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.
- Maintain trailing 252-session high using only completed data.
- RTH gap = today's 09:30 RTH open / previous RTH close - 1.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.25 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 34. Strategy: `Bull_BelowVAL_BelowPDL_Div`

**Family:** profile  
**Audit status:** CANDIDATE  
**Research rule:** bull200 + below prior VAL + below PDL + delta divergence  
**TP:** 0.75 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 456 trades  
**Net expectancy:** 0.757 ES points/trade  
**PF:** 1.119  
**Max DD:** 332.07 ES points  
**Discovery / Validation / OOS:** -0.953 / 0.881 / 3.156  

### Sierra implementation

- Use custom prior-day TPO `PriorVAL` from the parity profile engine.
- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 35. Strategy: `Bull_OR30L_SweepReclaim_Div`

**Family:** opening  
**Audit status:** CANDIDATE  
**Research rule:** bull200 + OR30-low sweep/reclaim + delta divergence  
**TP:** 0.25 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 313 trades  
**Net expectancy:** 0.360 ES points/trade  
**PF:** 1.067  
**Max DD:** 161.82 ES points  
**Discovery / Validation / OOS:** -0.028 / 0.244 / 1.024  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.25 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 36. Strategy: `Bull_OR15L_SweepReclaim_Div`

**Family:** opening  
**Audit status:** SENSITIVE  
**Research rule:** bull200 + OR15-low sweep/reclaim + delta divergence  
**TP:** 0.25 × ATR20  
**SL:** 0.50 × ATR20  
**Phase-4 sample:** 302 trades  
**Net expectancy:** 0.321 ES points/trade  
**PF:** 1.060  
**Max DD:** 298.82 ES points  
**Discovery / Validation / OOS:** 0.053 / -1.951 / 2.910  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.25 * ATR20
     stop   = entry - 0.50 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 37. Strategy: `OR30L_SweepReclaim_DeltaPos`

**Family:** opening  
**Audit status:** CANDIDATE  
**Research rule:** OR30-low sweep/reclaim + positive 5m delta  
**TP:** 0.50 × ATR20  
**SL:** 1.00 × ATR20  
**Phase-4 sample:** 1191 trades  
**Net expectancy:** 0.286 ES points/trade  
**PF:** 1.043  
**Max DD:** 415.69 ES points  
**Discovery / Validation / OOS:** -0.292 / 0.491 / 1.606  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.50 * ATR20
     stop   = entry - 1.00 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 38. Strategy: `Bull_PDL_Reclaim_POCbelow`

**Family:** profile  
**Audit status:** CANDIDATE  
**Research rule:** bull200 + PDL sweep/reclaim + close below prior POC + positive delta  
**TP:** 0.25 × ATR20  
**SL:** 1.50 × ATR20  
**Phase-4 sample:** 489 trades  
**Net expectancy:** 0.127 ES points/trade  
**PF:** 1.022  
**Max DD:** 288.71 ES points  
**Discovery / Validation / OOS:** -0.182 / 0.217 / 0.560  

### Sierra implementation

- Use custom prior-day TPO `PriorPOC` from the parity profile engine.
- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.25 * ATR20
     stop   = entry - 1.50 * ATR20
     time_stop = 120 minutes
ENDIF
```


## 39. Strategy: `Bull_PDL_SweepReclaim_Div`

**Family:** liquidity  
**Audit status:** SENSITIVE  
**Research rule:** bull200 + PDL sweep/reclaim + delta divergence  
**TP:** 1.00 × ATR20  
**SL:** 1.50 × ATR20  
**Phase-4 sample:** 134 trades  
**Net expectancy:** -0.574 ES points/trade  
**PF:** 0.919  
**Max DD:** 262.00 ES points  
**Discovery / Validation / OOS:** -3.173 / -1.736 / 3.386  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 1.00 * ATR20
     stop   = entry - 1.50 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 40. Strategy: `Bull_ONL_SweepReclaim_Div`

**Family:** liquidity  
**Audit status:** SENSITIVE  
**Research rule:** bull200 + overnight-low sweep/reclaim + delta divergence  
**TP:** 1.50 × ATR20  
**SL:** 0.50 × ATR20  
**Phase-4 sample:** 178 trades  
**Net expectancy:** -2.225 ES points/trade  
**PF:** 0.679  
**Max DD:** 432.87 ES points  
**Discovery / Validation / OOS:** -2.956 / -1.003 / -2.422  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 1.50 * ATR20
     stop   = entry - 0.50 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


## 41. Strategy: `Bull_R30ATR0.5_DeltaDiv`

**Family:** selloff  
**Audit status:** SENSITIVE  
**Research rule:** bull200 + 30m move <= -0.5 ATR20 + delta divergence  
**TP:** 0.75 × ATR20  
**SL:** 0.75 × ATR20  
**Phase-4 sample:** 39 trades  
**Net expectancy:** -4.322 ES points/trade  
**PF:** 0.662  
**Max DD:** 288.85 ES points  
**Discovery / Validation / OOS:** 4.922 / -8.495 / -10.903  

### Sierra implementation

- Require valid Bid/Ask data and use the exact Delta / divergence definition from this README.

### Full-auto gate

```text
IF strategy_enabled
AND master_trading_enabled
AND completed_signal_bar
AND strategy_rule == TRUE
AND not_traded_today_for_this_strategy
AND global_risk_gate == PASS
THEN submit long entry on next executable 1-minute open
     target = entry + 0.75 * ATR20
     stop   = entry - 0.75 * ATR20
     time_stop = 120 minutes
ENDIF
```

> **Implementation note:** keep this strategy disabled by default in LIVE mode. It is included for parity/research and requires further walk-forward approval.


---

## Strategy priority for implementation

Recommended order:

1. Implement **feature engine only**. No trading.
2. Export feature parity CSV from Sierra.
3. Compare Sierra vs Python for at least 100 manually selected timestamps covering:
   - ordinary bull day,
   - 5–10% correction,
   - 10%+ correction,
   - high-volatility day,
   - overnight sweep,
   - PDL sweep,
   - VWAP extreme,
   - positive and negative delta divergence.
4. Require exact/near-exact parity.
5. Implement strategy Boolean functions.
6. Export Sierra signals to CSV.
7. Compare signal timestamp sets against Python.
8. Implement SIM order execution.
9. Compare Sierra SIM trade log against research trade log.
10. Only after parity: paper/live forward test.

---

## Feature parity CSV schema

Sierra should export one row per completed 5-minute RTH bar:

```csv
Timestamp,Open,High,Low,Close,
PriorClose,PriorHigh,PriorLow,
ATR20,MA200,PriorATH,DrawdownFromATH,DrawdownBucket,
VWAP,VWAPSigma,VWAPZ,
PriorPOC,PriorVAH,PriorVAL,
OvernightHigh,OvernightLow,
OR15Low,OR30Low,
Delta5,CumDelta,Close30Ago,CumDelta30Ago,DeltaDiv30,DeltaFlipPositive,
LowerCloseStreak,
Signal_Strategy_01,...,Signal_Strategy_N
```

This file is the primary parity artifact for Codex/Astra/Python verification.

---

## Logging

Use `sc.AddMessageToLog` with a compact machine-readable format.

Example:

```text
ESALPHA|2026-09-25 10:35:00|Bull_Gap0.2_PDL_Reclaim|
Bull200=1|Gap=-0.0031|PDL=6712.25|Low=6710.50|Close=6713.00|
Delta5=1843|Signal=1
```

For every order:

```text
ESALPHA_ORDER|timestamp|strategy|qty|entry|target|stop|ATH_DD|ATR20|SIM/LIVE
```

Never log only "BUY". The state must be reconstructible later.

---

## Backtest / replay validation

Use Sierra Chart Replay and simulated trading.

Required validation cases:

- normal session,
- contract rollover,
- chart reload,
- data reconnect,
- Sierra restart,
- skipped/late bar,
- RTH holiday/short session,
- simultaneous TP/SL minute,
- entry near end of allowed window,
- network interruption,
- manual position already open,
- working order already present.

The system must never duplicate an order after recalculation or reconnect.

---

## Persistent state / recovery

Persist or reconstruct:

- last processed signal bar,
- current RTH date,
- per-strategy traded-today flag,
- ATH,
- daily OHLC history or sufficient arrays,
- current order IDs,
- active strategy ID,
- current position ownership.

Do not rely solely on in-memory variables for critical trade ownership. On startup/reconnect, reconcile against Sierra's current position and working orders.

---

## Live safety modes

Recommended enum:

```cpp
enum TradingMode
{
    MODE_DISABLED = 0,
    MODE_SIGNALS_ONLY = 1,
    MODE_SIM_AUTO = 2,
    MODE_LIVE_AUTO = 3
};
```

Default must be `MODE_DISABLED`.

A separate explicit input should be required for `MODE_LIVE_AUTO`.

---

## Position sizing

Phase-4 research contains experimental ATH drawdown multipliers:

```text
Flat:
0–5  = 1.00
5–10 = 1.00
10–15 = 1.00
15–20 = 1.00
20+ = 1.00

Moderate research:
0–5 = 1.00
5–10 = 1.25
10–15 = 1.50
15–20 = 1.75
20+ = 2.00

Aggressive research:
0–5 = 1.00
5–10 = 1.50
10–15 = 2.00
15–20 = 2.50
20+ = 3.00
```

**These multipliers are not production-approved.**

Preferred production research should eventually use volatility/risk-normalized quantity:

```text
RiskBudgetDollars / (StopDistancePoints * ESPointValue)
```

then optionally modify the risk budget by correction state only after statistical approval.

---

## Contract rollover

The Python research dataset is a continuous ES history.

Sierra live execution trades a specific futures contract.

Implementation must separate:

```text
ANALYSIS SYMBOL
vs
TRADE SYMBOL
```

Audit:
- roll dates,
- price gaps around rolls,
- ATH and MA series consistency,
- whether back-adjustment is used,
- whether level-based features (PDL, POC, VWAP) remain on the live contract scale.

Do not compare a back-adjusted research level directly with an unadjusted live-contract price.

---

## Market Profile warning

Native Sierra TPO/Volume Profile studies are useful visually, but research parity has priority.

The research TPO profile is a deliberately explicit reconstruction.

Therefore:

- do not silently replace it with Sierra native POC/VAH/VAL,
- if native values are desired later, create a separate strategy version,
- label that version separately and backtest it independently.

---

## ACSIL implementation checklist

### Build
- [ ] Remote Build or local Visual C++ build succeeds.
- [ ] No warnings about uninitialized state.
- [ ] 64-bit DLL loaded.

### Data
- [ ] ES Tick Size = 0.25.
- [ ] Bid/Ask volume present.
- [ ] Evening session present.
- [ ] At least 252 completed sessions loaded.
- [ ] At least 200 sessions for MA200.
- [ ] Volume-at-price maintained where needed.

### Feature parity
- [ ] ATR20 parity.
- [ ] MA200 parity.
- [ ] ATH parity.
- [ ] VWAP parity.
- [ ] sigma parity.
- [ ] POC parity.
- [ ] VAH parity.
- [ ] VAL parity.
- [ ] overnight level parity.
- [ ] OR parity.
- [ ] delta parity.
- [ ] delta-divergence parity.

### Signal parity
- [ ] Strategy signal timestamp matches Python.
- [ ] No duplicate signals.
- [ ] No intrabar look-ahead.
- [ ] One-first-signal-per-day rule matches.

### Execution
- [ ] Entry uses next executable minute.
- [ ] Attached TP/SL generated correctly.
- [ ] 120-minute time stop.
- [ ] Position reconciliation after reconnect.
- [ ] Daily risk limit.
- [ ] Flatten logic.

### Deployment
- [ ] Signals-only mode passed.
- [ ] Replay SIM passed.
- [ ] Forward SIM passed.
- [ ] Live mode manually enabled only after approval.

---

## Files to keep beside the Sierra source

```text
README_SIERRA_CHART_ACSIL.md
codex_astra_strategy_spec.json
strategy_summary.csv
drawdown_bucket_performance.csv
historical_correction_frequency.csv
sp500_major_bear_markets.csv
```

These files form the audit trail.

---

## Final rule for Codex / GPT Astra

When changing the Sierra implementation:

1. Never alter a feature definition just to improve performance.
2. If a definition changes, create a **new version**.
3. Re-run the Python benchmark.
4. Re-run Sierra parity.
5. Compare timestamps and trade logs.
6. Preserve the old version and results.
7. Never merge "research" and "production" behavior silently.

The correct engineering objective is not to reproduce a beautiful equity curve.

The objective is to reproduce **the exact same causal information set in Python, Sierra Replay, and live Sierra Chart**.
